-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: expoeduc_expoeduca
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `datosProyecto`
--

DROP TABLE IF EXISTS `datosProyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datosProyecto` (
  `idProyecto` int(11) NOT NULL AUTO_INCREMENT,
  `Year` int(11) DEFAULT NULL,
  `Banner` varchar(150) DEFAULT NULL,
  `Titulo` varchar(50) DEFAULT NULL,
  `Introduccion` varchar(250) DEFAULT NULL,
  `Descripcion` longtext,
  `Alumno_Responsable` int(11) NOT NULL,
  `Estado` int(11) DEFAULT NULL,
  `Orientacion` int(11) DEFAULT NULL,
  `ndolocal` int(11) DEFAULT NULL,
  `ImagenPrincipal` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`idProyecto`),
  KEY `fkAlumno_idx` (`Alumno_Responsable`),
  KEY `fkOrientacion_idx` (`Orientacion`),
  CONSTRAINT `fkAlumno` FOREIGN KEY (`Alumno_Responsable`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datosProyecto`
--

LOCK TABLES `datosProyecto` WRITE;
/*!40000 ALTER TABLE `datosProyecto` DISABLE KEYS */;
INSERT INTO `datosProyecto` (`idProyecto`, `Year`, `Banner`, `Titulo`, `Introduccion`, `Descripcion`, `Alumno_Responsable`, `Estado`, `Orientacion`, `ndolocal`, `ImagenPrincipal`) VALUES (122,5,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT122/bannerLasRosas.jpg','Biblioteca,  2do Proyecto ProgramaciÃ³n','El proyecto de programaciÃ³n consta de una biblioteca que permite almacenar libros o cualquier tipo de documento. Permite ingresar, modificar y buscar distintos tipos de documentos.                                                                     ','<p style=\"text-align: center;\" data-mce-style=\"text-align: center;\"><span style=\"color: rgb(35, 111, 161);\" data-mce-style=\"color: #236fa1;\"><strong>PROGRAMA</strong></span></p><p><br></p><p><br></p><p>El programa consiste &nbsp;en un sitema de base de datos documental, que permite el ingreso de cualquier tipo de material al mismo como Libros, Revistas, Facturas,Documentos personales, Legales o apuntes. Existen 2 niveles de usuario , un usuario normal y un usuario administrador. El nivel de usuario administrador tiene permitido realizar los siguentes movimientos: . Alta de materiales , &nbsp;Alta de usuarios, Borrado de materiales, &nbsp;ModificaciÃ³n de materiales y Consultas , mientras que el usuario solo podra realizar alta de materiales y consultas.&nbsp;</p><p>Altas: Se deben ingresar atributos tales como : codigo, tipo de material, &nbsp;fecha de caducidad, tomo, paginas y precio.</p><p>Bajas: Solo se puede realizar esta accion si el usuario tiene el nivel requerido (administrador).</p><p>Modificaciones: Solo se puede realizar esta accion si el usuario tiene el nivel requerido ( administrador). Hay un tipo de Usuario especial (El BIBLIOTECARIO) que puede se le da<br>permiros especiales para cierto tipo de tareas, por ejemplo poder reclasificary para ello necesita el permiso especial para solamente poder modificar el campo del codigo.</p><p>Busquedas: Es un sistema agil y preciso para realizar las bÃºsquedas, por lo que se ontiene los operadores and y or para insertar entre los campos a<br>buscar.</p><p>Menu de configuracion: Los administradores son los Ãºnicos capaces de realizar operaciones en el menu deconfiguracion. Consta de algunas opciones como :-puede asignar o quitar un usuario comÃºn a nivel de Bibliotecario o Administrador.-Puede agregar, modificar o quitar la lista seleccionable de tipo de material.-Cada tipo de material, puede configurarse para aceptar tomo, precio, paginas en forma independiente.&nbsp;</p>',148,1,15,3,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT122/biblioteca digital.jpg'),(123,5,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT123/Banner.jpg','ExpoEduca, 2do Informatica','Es un proyecto desarrollado por 2do de informÃ¡tica en el cual consiste en dar soporte a la feria de proyectos fÃ­sica del presente aÃ±o con una web dinÃ¡mica que permite cargar y exhibir todos los proyectos de este aÃ±o en el IEP .                  ','<p style=\"text-align: center;\" data-mce-style=\"text-align: center;\"><strong><span style=\"color: rgb(35, 111, 161); font-size: 24pt;\" data-mce-style=\"color: #236fa1; font-size: 24pt;\">PROYECTO</span></strong></p><p style=\"text-align: left;\" data-mce-style=\"text-align: left;\">El objetivo principal de nuestro proyecto EXPOEDUCA es llevar a la prÃ¡ctica todo el aprendizaje del aÃ±o en lo que respecta al diseÃ±o y la programaciÃ³n de un sitio web. Dentro de ese marco educativo, se nos planteÃ³ realizar este sitio que consiste en mostrar en forma virtual todos los proyectos que han encarado los diferentes grupo (teniendo en cuenta que este aÃ±o no se realizarÃ¡ la expo en forma presencial debido a las notorias circunstancias).</p><p style=\"text-align: left;\" data-mce-style=\"text-align: left;\"><br data-mce-bogus=\"1\"></p><p style=\"text-align: center;\" data-mce-style=\"text-align: center;\"><span style=\"color: rgb(35, 111, 161); font-size: 24pt;\" data-mce-style=\"color: #236fa1; font-size: 24pt;\"><strong>LA PAGINA:ï»¿</strong></span></p><p><br></p><p>El sitio web consta de &nbsp;una pagina principal que tiene &nbsp;3 simples opciones, que son :&nbsp;</p><ul><li><strong>Inicio</strong>: Es un boton te dirije a la pagina central en caso de no estar alli.</li><li><strong>Proyectos:</strong> accede a el buscador de proyectos donde se van a encontrar los proyectos ya cargados y listos para exhibir. </li><li><strong>Informacion:</strong> muestra informacion general del liceo.</li></ul><p><br>ademas de esto tenemos el login.<br>Login: consiste en iniciar sesion en la pagina con 3 niveles de permisos, estos permisos dan diferentes opciones a distintos usuarios, estos tipos de usuarios son:<br>&nbsp; &nbsp; Alumno: tiene funciones de subir proyectos.<br>&nbsp; &nbsp; Profesor: tiene la opcion de aprobar de proyectos.<br>&nbsp; &nbsp; Administrador: tiene el control de aprobar las solicitudes de proyectos y las solicitudes de &nbsp; &nbsp; usuarios.&nbsp;<br>En el boton de login tenes la opcion de crear un usuario en caso de que no tengas ninguno. Cuando te logeas como alumno se te habilita una opcion de administrar donde se puede acceder a una pagina la cual te permite subir informacion sobre el proyecto donde se incluye(subir imagenes,subir videos mediante una url,subir un banner,ingresar una descripcion corta la cual no puede tener mas de 250 caracteres y una descripcion larga la cual permite cuantos caracteres quieras).</p>',149,1,15,3,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT123/principalexpo.webp');
/*!40000 ALTER TABLE `datosProyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encuestas`
--

DROP TABLE IF EXISTS `encuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `encuestas` (
  `idProyecto` int(11) DEFAULT NULL,
  `Sexo` int(11) DEFAULT NULL,
  `Edad` varchar(45) DEFAULT NULL,
  `ColoresObservados` int(11) DEFAULT NULL COMMENT '1=Blanco y Dorado\n2=Azul y Negro',
  `Diurnos_Nocturnos` int(11) DEFAULT NULL COMMENT '1=Diurnos\n2=Nocturnos',
  `OtrosColores` varchar(50) DEFAULT NULL COMMENT 'Por si no ve ninguno de los colores que se suponen que tiene que ver se agrega aca los colores que vio',
  KEY `fkProyectoEncuestas_idx` (`idProyecto`),
  CONSTRAINT `fkProyectoEncuestas` FOREIGN KEY (`idProyecto`) REFERENCES `datosProyecto` (`idProyecto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encuestas`
--

LOCK TABLES `encuestas` WRITE;
/*!40000 ALTER TABLE `encuestas` DISABLE KEYS */;
/*!40000 ALTER TABLE `encuestas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagenes`
--

DROP TABLE IF EXISTS `imagenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagenes` (
  `idImagen` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(150) DEFAULT NULL,
  `idProyecto` int(11) DEFAULT NULL,
  PRIMARY KEY (`idImagen`),
  KEY `fkProyectoImg_idx` (`idProyecto`),
  CONSTRAINT `fkProyectoImg` FOREIGN KEY (`idProyecto`) REFERENCES `datosProyecto` (`idProyecto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagenes`
--

LOCK TABLES `imagenes` WRITE;
/*!40000 ALTER TABLE `imagenes` DISABLE KEYS */;
INSERT INTO `imagenes` (`idImagen`, `url`, `idProyecto`) VALUES (1,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT122/BIBLIOTECA1.png',122),(2,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT123/WEB1.png',123),(5,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT122/probamosimagen.png',122),(7,'http://expoeduca.liceoiep.edu.uy/iep/img/PROYECT123/expocaptura1.png',123);
/*!40000 ALTER TABLE `imagenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orientaciones`
--

DROP TABLE IF EXISTS `orientaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orientaciones` (
  `Nombre` varchar(40) DEFAULT NULL,
  `idOrientacion` int(11) NOT NULL,
  `Local` int(11) DEFAULT NULL,
  PRIMARY KEY (`idOrientacion`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orientaciones`
--

LOCK TABLES `orientaciones` WRITE;
/*!40000 ALTER TABLE `orientaciones` DISABLE KEYS */;
INSERT INTO `orientaciones` (`Nombre`, `idOrientacion`, `Local`) VALUES ('Informatica',15,3),('Administracion',1,3),('Deporte',2,3),('Cientifico',3,1),('Biologico',4,1),('Humanistico',5,1),('Artistico',6,1),('Ingeniera',7,1),('Arquitecutra',8,1),('Medicina',9,1),('Agronomia',10,1),('Economia',11,1),('Derecho',12,1),('Ciclo Basico',13,2),('Cuarto año',14,1),('Ingles',16,3),('Ingles Diversificado',17,1),('Ingles Ciclo Basico',18,2),('Ingles Tecnologico',19,3);
/*!40000 ALTER TABLE `orientaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectoProfesor`
--

DROP TABLE IF EXISTS `proyectoProfesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectoProfesor` (
  `idProyecto` int(11) DEFAULT NULL,
  `idProfesor` int(11) DEFAULT NULL,
  `Responsable` tinyint(4) DEFAULT NULL,
  KEY `fkProyecto_idx` (`idProyecto`),
  KEY `fkProfesor_idx` (`idProfesor`),
  CONSTRAINT `fkProfesor` FOREIGN KEY (`idProfesor`) REFERENCES `usuario` (`idUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fkProyecto` FOREIGN KEY (`idProyecto`) REFERENCES `datosProyecto` (`idProyecto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectoProfesor`
--

LOCK TABLES `proyectoProfesor` WRITE;
/*!40000 ALTER TABLE `proyectoProfesor` DISABLE KEYS */;
INSERT INTO `proyectoProfesor` (`idProyecto`, `idProfesor`, `Responsable`) VALUES (122,150,1),(123,150,1),(122,151,1),(123,151,1),(122,152,1),(123,152,1);
/*!40000 ALTER TABLE `proyectoProfesor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitud_profesor`
--

DROP TABLE IF EXISTS `solicitud_profesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitud_profesor` (
  `Nombre` varchar(45) DEFAULT NULL,
  `Apellido` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Telefono` varchar(45) DEFAULT NULL,
  `Usuario` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `idSoliProf` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idSoliProf`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud_profesor`
--

LOCK TABLES `solicitud_profesor` WRITE;
/*!40000 ALTER TABLE `solicitud_profesor` DISABLE KEYS */;
/*!40000 ALTER TABLE `solicitud_profesor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitud_usuario`
--

DROP TABLE IF EXISTS `solicitud_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitud_usuario` (
  `Usuario` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Nombre` varchar(45) DEFAULT NULL,
  `Apellido` varchar(45) DEFAULT NULL,
  `Titulo_Proyecto` varchar(45) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `Orientacion` int(11) DEFAULT NULL,
  `idSoli_Usuario` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idSoli_Usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud_usuario`
--

LOCK TABLES `solicitud_usuario` WRITE;
/*!40000 ALTER TABLE `solicitud_usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `solicitud_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `TipoUsuario` int(11) DEFAULT NULL COMMENT '0 = Administrador\n1 = Profesor\n2 = Alumno',
  `Usuario` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `Nombre` varchar(45) DEFAULT NULL,
  `Apellido` varchar(45) DEFAULT NULL,
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(45) DEFAULT NULL,
  `Telefono` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`TipoUsuario`, `Usuario`, `Password`, `Nombre`, `Apellido`, `idUsuario`, `Email`, `Telefono`) VALUES (0,'2Informatica','inf0rm4t1c4','Sol','Roqueta',1,'solroquetasorloqueta@gmail.com','098208189'),(2,'2doProgramacion','Programacion','Programacion','Programacion',148,'santycaze@gmail.com',NULL),(2,'2doWeb','2doWeb','2doWeb','2doWeb',149,'santycaze@gmail.com',NULL),(1,'2doinformatik','2doinformatik','2doinformatik','2doinformatik',150,'santycaze@gmail.com',NULL),(1,'Grillo','1111','Daniel','Grillo',151,'d.grillo2012@gmail.com',NULL),(1,'ProfeSergio','manz34sol25-','Sergio','Acosta',152,'sasehara0@gmail.com',NULL),(1,'RPaggiola','Abc123456','RamÃ³n','Paggiola Prego',153,'proferamonpapre@gmail.com','097217970'),(1,'Cecil','catayfran','Cecilia','Olivera Font',154,'cecifosil@gmail.com','099679424'),(1,'Leticiapm','leticia1','Leticia','Pintos',155,'leticiapintosm@gmail.com','097099411'),(1,'Rigasu','rasr0585Â·','Richard ','SuÃ¡rez',156,'profeadmrichard@gmail.com','098301929'),(1,'Sandra De Carlo','liceoiep2020','Sandra','De Carlo',157,'sandra.decarlo.iep@gmail.com','098267871'),(1,'Erika Poo Canto','10140018','Erika','Poo Canto',158,'erikapoocanto@gmail.com','098339253'),(1,'dreamsns1982@gmail.com','naty1982','Natalia','Sanchez',159,'dreamsns1982@gmail.com','094625007');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videos` (
  `url` varchar(150) DEFAULT NULL,
  `idVideo` int(11) NOT NULL AUTO_INCREMENT,
  `idProyecto` int(11) DEFAULT NULL,
  PRIMARY KEY (`idVideo`),
  KEY `fkProyectoVideo_idx` (`idProyecto`),
  CONSTRAINT `fkProyectoVideo` FOREIGN KEY (`idProyecto`) REFERENCES `datosProyecto` (`idProyecto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'expoeduc_expoeduca'
--

--
-- Dumping routines for database 'expoeduc_expoeduca'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-17  8:11:11
