$( document ).ready(function() {
    $.ajax({
        url:"CargoPlanilla.php", 
        type: "post", 
        success:function(content){
          $('.Planilla').html(content);
         
        function agrando(foto){
          alert(foto);
        }
        
      }
    });
    // MODAL que carga imagenes
    //-- Modal Agrandar Fotos -->
});