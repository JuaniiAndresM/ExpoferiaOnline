function hfindex() {
  $("#header").load("/ExpoferiaOnline/HeaderFooter/header.php");
  $("#footer").load("/ExpoferiaOnline/HeaderFooter/footer.html");
}
