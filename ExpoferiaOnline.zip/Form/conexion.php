<?php
//Open a new connection to the MySQL server
$mysqli = new mysqli('expoeduca.liceoiep.edu.uy','expoeduc_informatica2','LiceoIep_2020_2do_Inf','expoeduc_expoeduca');


//Output any connection error
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

?>